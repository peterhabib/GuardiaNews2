package com.example.gaurdianews;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.Loader;
import android.util.Log;

import java.util.List;

@SuppressWarnings("ALL")
public class LoadNews extends AsyncTaskLoader<List<News>> {

    private static final String LOG_TAG = LoadNews.class.getName();

    private String mUrl;

    public LoadNews(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<News> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        // Perform the network request, parse the response, and extract a list of news.
        List<News> news = QueryUtils.fetchNewsData(mUrl);
        return news;
    }
}